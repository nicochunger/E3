/* Automatically generated - do not edit! */

#include <dx/dx.h>
#include <dx/modflags.h>

DXEntry()
{
    {
        extern Error m_ReplicateCell(Object *, Object *);
        DXAddModule("ReplicateCell", m_ReplicateCell, 0,
            3, "udata_field", "replication_dim", "lattice_vectors",
            1, "replicated_field");
    }
}
