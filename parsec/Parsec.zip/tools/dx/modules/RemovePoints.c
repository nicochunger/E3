/*
 * Automatically generated on "/tmp/RemovePoints.mb" by DX Module Builder
 */

#include "dx/dx.h"

static Error traverse(Object *, Object *);
static Error doLeaf(Object *, Object *);

/*
 * Declare the interface routine.
 */
int
RemovePoints_worker(
    int, int, float *,
    int, float *,
    int, float *,
    int, float *,
    int, float *);

Error
m_RemovePoints(Object *in, Object *out)
{
  int i;

  /*
   * Initialize all outputs to NULL
   */
  out[0] = NULL;

  /*
   * Error checks: required inputs are verified.
   */

  /* Parameter "field" is required. */
  if (in[0] == NULL)
  {
    DXSetError(ERROR_MISSING_DATA, "\"field\" must be specified");
    return ERROR;
  }


  /*
   * Since output "output_1" is structure Field/Group, it initially
   * is a copy of input "field".
   */
  out[0] = DXCopy(in[0], COPY_STRUCTURE);
  if (! out[0])
    goto error;

  /*
   * If in[0] was an array, then no copy is actually made - Copy 
   * returns a pointer to the input object.  Since this can't be written to
   * we postpone explicitly copying it until the leaf level, when we'll need
   * to be creating writable arrays anyway.
   */
  if (out[0] == in[0])
    out[0] = NULL;

  /*
   * Call the hierarchical object traversal routine
   */
  if (!traverse(in, out))
    goto error;

  return OK;

error:
  /*
   * On error, any successfully-created outputs are deleted.
   */
  for (i = 0; i < 1; i++)
  {
    if (in[i] != out[i])
      DXDelete(out[i]);
    out[i] = NULL;
  }
  return ERROR;
}


static Error
traverse(Object *in, Object *out)
{
  switch(DXGetObjectClass(in[0]))
  {
    case CLASS_FIELD:
    case CLASS_ARRAY:
    case CLASS_STRING:
      /*
       * If we have made it to the leaf level, call the leaf handler.
       */
      if (! doLeaf(in, out))
  	     return ERROR;

      return OK;

    case CLASS_GROUP:
    {
      int   i, j;
      int   memknt;
      Class groupClass  = DXGetGroupClass((Group)in[0]);

      DXGetMemberCount((Group)in[0], &memknt);


       /*
        * Create new in and out lists for each child
        * of the first input. 
        */
        for (i = 0; i < memknt; i++)
        {
          Object new_in[3], new_out[1];

         /*
          * For all inputs that are Values, pass them to 
          * child object list.  For all that are Field/Group, get 
          * the appropriate decendent and place it into the
          * child input object list.
          */

          /* input "field" is Field/Group */
          if (in[0])
            new_in[0] = DXGetEnumeratedMember((Group)in[0], i, NULL);
          else
            new_in[0] = NULL;

          /* input "radius" is Value */
          new_in[1] = in[1];

          /* input "probe_input" is Value */
          new_in[2] = in[2];

         /*
          * For all outputs that are Values, pass them to 
          * child object list.  For all that are Field/Group,  get
          * the appropriate decendent and place it into the
          * child output object list.  Note that none should
          * be NULL (unlike inputs, which can default).
          */

          /* output "output_1" is Field/Group */
          new_out[0] = DXGetEnumeratedMember((Group)out[0], i, NULL);

          if (! traverse(new_in, new_out))
            return ERROR;

         /*
          * Now for each output that is not a Value, replace
          * the updated child into the object in the parent.
          */

          /* output "output_1" is Field/Group */
          DXSetEnumeratedMember((Group)out[0], i, new_out[0]);

        }
      return OK;
    }

    case CLASS_XFORM:
    {
      int    i, j;
      Object new_in[3], new_out[1];


      /*
       * Create new in and out lists for the decendent of the
       * first input.  For inputs and outputs that are Values
       * copy them into the new in and out lists.  Otherwise
       * get the corresponding decendents.
       */

      /* input "field" is Field/Group */
      if (in[0])
        DXGetXformInfo((Xform)in[0], &new_in[0], NULL);
      else
        new_in[0] = NULL;

      /* input "radius" is Value */
      new_in[1] = in[1];

      /* input "probe_input" is Value */
      new_in[2] = in[2];

      /*
       * For all outputs that are Values, copy them to 
       * child object list.  For all that are Field/Group,  get
       * the appropriate decendent and place it into the
       * child output object list.  Note that none should
       * be NULL (unlike inputs, which can default).
       */

      /* output "output_1" is Field/Group */
      DXGetXformInfo((Xform)out[0], &new_out[0], NULL);

      if (! traverse(new_in, new_out))
        return ERROR;

      /*
       * Now for each output that is not a Value replace
       * the updated child into the object in the parent.
       */

      /* output "output_1" is Field/Group */
      DXSetXformObject((Xform)out[0], new_out[0]);

      return OK;
    }

    case CLASS_SCREEN:
    {
      int    i, j;
      Object new_in[3], new_out[1];


      /*
       * Create new in and out lists for the decendent of the
       * first input.  For inputs and outputs that are Values
       * copy them into the new in and out lists.  Otherwise
       * get the corresponding decendents.
       */

      /* input "field" is Field/Group */
      if (in[0])
        DXGetScreenInfo((Screen)in[0], &new_in[0], NULL, NULL);
      else
        new_in[0] = NULL;

      /* input "radius" is Value */
      new_in[1] = in[1];

      /* input "probe_input" is Value */
      new_in[2] = in[2];


      /*
       * For all outputs that are Values, copy them to 
       * child object list.  For all that are Field/Group,  get
       * the appropriate decendent and place it into the
       * child output object list.  Note that none should
       * be NULL (unlike inputs, which can default).
       */

       /* output "output_1" is Field/Group */
       DXGetScreenInfo((Screen)out[0], &new_out[0], NULL, NULL);

       if (! traverse(new_in, new_out))
         return ERROR;

      /*
       * Now for each output that is not a Value, replace
       * the updated child into the object in the parent.
       */

      /* output "output_1" is Field/Group */
       DXSetScreenObject((Screen)out[0], new_out[0]);

       return OK;
     }

     case CLASS_CLIPPED:
     {
       int    i, j;
       Object new_in[3], new_out[1];


       /* input "field" is Field/Group */
       if (in[0])
         DXGetClippedInfo((Clipped)in[0], &new_in[0], NULL);
       else
         new_in[0] = NULL;

       /* input "radius" is Value */
       new_in[1] = in[1];

       /* input "probe_input" is Value */
       new_in[2] = in[2];


      /*
       * For all outputs that are Values, copy them to 
       * child object list.  For all that are Field/Group,  get
       * the appropriate decendent and place it into the
       * child output object list.  Note that none should
       * be NULL (unlike inputs, which can default).
       */

       /* output "output_1" is Field/Group */
       DXGetClippedInfo((Clipped)out[0], &new_out[0], NULL);

       if (! traverse(new_in, new_out))
         return ERROR;

      /*
       * Now for each output that is not a Value, replace
       * the updated child into the object in the parent.
       */

       /* output "output_1" is Field/Group */
       DXSetClippedObjects((Clipped)out[0], new_out[0], NULL);

       return OK;
     }

     default:
     {
       DXSetError(ERROR_BAD_CLASS, "encountered in object traversal");
       return ERROR;
     }
  }
}

static int
doLeaf(Object *in, Object *out)
{
  int i, result=0;
  Array array;
  Field field;
  Pointer *in_data[3], *out_data[1];
  int in_knt[3], out_knt[1];
  Type type;
  Category category;
  int rank, shape;
  Object attr, src_dependency_attr = NULL;
  char *src_dependency = NULL;
  /*
   * Irregular positions info
   */
  int p_knt, p_dim;
  float *p_positions;
  int c_knt = -1;
  /* BERND variables */
  int j, ipick,iout;
  float radius,vec[3];
  Point *oldpositions_ptr, *inpoint, *newpositions_ptr;
  float *olddata_ptr, *newdata_ptr;
  Array newdata, newpositions;
  char mstring[255];



  /* ==================== HANDLE THE INPUT FIELD ==================== */


  /*
   * positions and/or connections are required, so the first must
   * be a field.
   */
  if (DXGetObjectClass(in[0]) != CLASS_FIELD)
  {
      DXSetError(ERROR_INVALID_DATA,
           "positions and/or connections unavailable in array object");
      goto error;
  }
  else
  {

    field = (Field)in[0];

    if (DXEmptyField(field))
      return OK;

    /* 
     * Determine the dependency of the source object's data
     * component.
     */
    src_dependency_attr = DXGetComponentAttribute(field, "data", "dep");
    if (! src_dependency_attr)
    {
      DXSetError(ERROR_MISSING_DATA, "\"field\" data component is missing a dependency attribute");
      goto error;
    }

    if (DXGetObjectClass(src_dependency_attr) != CLASS_STRING)
    {
      DXSetError(ERROR_BAD_CLASS, "\"field\" dependency attribute");
      goto error;
    }

    src_dependency = DXGetString((String)src_dependency_attr);

    array = (Array)DXGetComponentValue(field, "positions");
    if (! array)
    {
      DXSetError(ERROR_BAD_CLASS, "\"field\" contains no positions component");
      goto error;
    }

    /* 
     * The user requested irregular positions.  So we
     * get the count, the dimensionality and a pointer to the
     * explicitly enumerated positions.  If the positions
     * are in fact regular, this will expand them.
     */
    DXGetArrayInfo(array, &p_knt, NULL, NULL, NULL, &p_dim);

    p_positions = (float *)DXGetArrayData(array);
    if (! p_positions)
      goto error;

    /* 
     * If there are connections, get their count so that
     * connections-dependent result arrays can be sized.
     */
    array = (Array)DXGetComponentValue(field, "connections");
    if (array)
        DXGetArrayInfo(array, &c_knt, NULL, NULL, NULL, NULL);
  }
  /*
   * If the input argument is not NULL then we get the 
   * data array: either the object itself, if its an 
   * array, or the data component if the argument is a field
   */
  if (! in[0])
  {
    array = NULL;
    in_data[0] = NULL;
    in_knt[0] = NULL;
  }
  else
  {
    if (DXGetObjectClass(in[0]) == CLASS_ARRAY)
    {
      array = (Array)in[0];
    }
    else if (DXGetObjectClass(in[0]) == CLASS_STRING)
    {
      in_data[0] = (Pointer)DXGetString((String)in[0]);
      in_knt[0] = 1;
    }
    else
    {
      if (DXGetObjectClass(in[0]) != CLASS_FIELD)
      {
        DXSetError(ERROR_BAD_CLASS, "\"field\" should be a field");
        goto error;
      }

      array = (Array)DXGetComponentValue((Field)in[0], "data");
      if (! array)
      {
        DXSetError(ERROR_MISSING_DATA, "\"field\" has no data component");
        goto error;
      }

      if (DXGetObjectClass((Object)array) != CLASS_ARRAY)
      {
        DXSetError(ERROR_BAD_CLASS, "data component of \"field\" should be an array");
        goto error;
      }
    }

    /* 
     * get the dependency of the data component
     */
    attr = DXGetAttribute((Object)array, "dep");
    if (! attr)
    {
      DXSetError(ERROR_MISSING_DATA, "data component of \"field\" has no dependency");
      goto error;
    }

    if (DXGetObjectClass(attr) != CLASS_STRING)
    {
      DXSetError(ERROR_BAD_CLASS, "dependency attribute of data component of \"field\"");
      goto error;
    }

  /*
   * The dependency of this arg should be positions
   */
    if (strcmp("positions", DXGetString((String)attr)))
    {
      DXSetError(ERROR_INVALID_DATA, "data dependency of \"field\" must be positions");
      goto error;
    }

    if (DXGetObjectClass(in[0]) != CLASS_STRING)    {
       DXGetArrayInfo(array, &in_knt[0], &type, &category, &rank, &shape);
       if (type != TYPE_FLOAT || category != CATEGORY_REAL ||
             !((rank == 0) || ((rank == 1)&&(shape == 1))))
       {
         DXSetError(ERROR_INVALID_DATA, "input \"field\"");
         goto error;
       }

       in_data[0] = DXGetArrayData(array);
       if (! in_data[0])
          goto error;

    }
  }

  /* ==================== HANDLE THE RADIUS INPUT ==================== */



  /*
   * If the input argument is not NULL then we get the 
   * data array: either the object itself, if its an 
   * array, or the data component if the argument is a field
   */
  if (! in[1])
  {
    array = NULL;
    in_data[1] = NULL;
    in_knt[1] = NULL;
  }
  else
  {
    if (DXGetObjectClass(in[1]) == CLASS_ARRAY)
    {
      array = (Array)in[1];
    }
    else if (DXGetObjectClass(in[1]) == CLASS_STRING)
    {
      in_data[1] = (Pointer)DXGetString((String)in[1]);
      in_knt[1] = 1;
    }
    else
    {
      if (DXGetObjectClass(in[1]) != CLASS_FIELD)
      {
        DXSetError(ERROR_BAD_CLASS, "\"radius\" should be a field");
        goto error;
      }

      array = (Array)DXGetComponentValue((Field)in[1], "data");
      if (! array)
      {
        DXSetError(ERROR_MISSING_DATA, "\"radius\" has no data component");
        goto error;
      }

      if (DXGetObjectClass((Object)array) != CLASS_ARRAY)
      {
        DXSetError(ERROR_BAD_CLASS, "data component of \"radius\" should be an array");
        goto error;
      }
    }


    if (DXGetObjectClass(in[1]) != CLASS_STRING)    {
       DXGetArrayInfo(array, &in_knt[1], &type, &category, &rank, &shape);
       if (type != TYPE_FLOAT || category != CATEGORY_REAL ||
             !((rank == 0) || ((rank == 1)&&(shape == 1))))
       {
         DXSetError(ERROR_INVALID_DATA, "input \"radius\"");
         goto error;
       }

       in_data[1] = DXGetArrayData(array);
       if (! in_data[1])
          goto error;

    }
  }

  /* ==================== HANDLE THE PROBE POSITION ==================== */


  /*
   * If the input argument is not NULL then we get the 
   * data array: either the object itself, if its an 
   * array, or the data component if the argument is a field
   */
  if (! in[2])
  {
    array = NULL;
    in_data[2] = NULL;
    in_knt[2] = NULL;
  }
  else
  {
    if (DXGetObjectClass(in[2]) == CLASS_ARRAY)
    {
      array = (Array)in[2];
    }
    else if (DXGetObjectClass(in[2]) == CLASS_STRING)
    {
      in_data[2] = (Pointer)DXGetString((String)in[2]);
      in_knt[2] = 1;
    }
    else
    {
      if (DXGetObjectClass(in[2]) != CLASS_FIELD)
      {
        DXSetError(ERROR_BAD_CLASS, "\"probe_input\" should be a field");
        goto error;
      }

      array = (Array)DXGetComponentValue((Field)in[2], "data");
      if (! array)
      {
        DXSetError(ERROR_MISSING_DATA, "\"probe_input\" has no data component");
        goto error;
      }

      if (DXGetObjectClass((Object)array) != CLASS_ARRAY)
      {
        DXSetError(ERROR_BAD_CLASS, "data component of \"probe_input\" should be an array");
        goto error;
      }
    }


    if (DXGetObjectClass(in[2]) != CLASS_STRING)    {
       DXGetArrayInfo(array, &in_knt[2], &type, &category, &rank, &shape);
       if (type != TYPE_FLOAT || category != CATEGORY_REAL ||
           rank != 1 || shape != 3)
       {
         DXSetError(ERROR_INVALID_DATA, "input \"probe_input\"");
         goto error;
       }

       in_data[2] = DXGetArrayData(array);
       if (! in_data[2])
          goto error;

    }
  }

  /* ======================== SEARCH FOR POSITIONS ============ */

  /* Now search for the probe position in the field */

  oldpositions_ptr = (Point *)p_positions;
  olddata_ptr = (float *)in_data[0];

  if(in[1]) 
    radius = *((float*)in_data[1]);
  else radius =0.2;
  sprintf(mstring," RADIUS=%f",radius);
  DXMessage(mstring);

  radius *=radius;

  sprintf(mstring," LIST OF PROBED POINTS:");
  DXMessage(mstring);

  for(j=0;j<in_knt[2]; j++) { /* loop through all probes */
    vec[0] = *((float*) in_data[2]   +3*j);
    vec[1] = *((float*) in_data[2]+1 +3*j);
    vec[2] = *((float*) in_data[2]+2 +3*j);
    sprintf(mstring," %f %f %f", vec[0], vec[1], vec[2]);
    DXMessage(mstring);
  }


  iout=in_knt[0];
  if(in[2]) {   /* there is a request to remove positions */
    iout=0;
    for (i=0; i<in_knt[0]; i++) { /* loop through all elements */
      /* check if it is selected by one of the probes */
      ipick=0;
      for(j=0;j<in_knt[2]; j++) { /* loop through all probes */
	vec[0] = *((float*) in_data[2]   +3*j);
	vec[1] = *((float*) in_data[2]+1 +3*j);
	vec[2] = *((float*) in_data[2]+2 +3*j);
	inpoint = oldpositions_ptr+i;
	if( (vec[0]-inpoint->x)*(vec[0]-inpoint->x) + (vec[1]-inpoint->y)*(vec[1]-inpoint->y) + (vec[2]-inpoint->z)*(vec[2]-inpoint->z) < radius) ipick=1;
      }
      if(ipick==0) iout++;
    }
  }
  out_knt[0]=iout;
  
  sprintf(mstring," %d ELEMENTS WILL BE TRANSPORTED",iout);
  DXMessage(mstring);

  /* strip off old garbage */
  DXChangedComponentStructure((Field)out[0], "positions");

  /*
   * Create an output data array typed according to the
   * specification given
   */
  array = DXNewArray(TYPE_FLOAT, CATEGORY_REAL, 0, 0);
  if (! array)
    goto error;

  /*
   * Set the dependency of the array to the same as the first input
   */
  if (src_dependency_attr != NULL)
    if (! DXSetAttribute((Object)array, "dep", src_dependency_attr))
      goto error;

  /*
   * Actually allocate the array data space
   */
  if (! DXAddArrayData(array, 0, out_knt[0], NULL))
    goto error;

  /*
   * If the output vector slot is not NULL, then it better be a field, and
   * we'll add the new array to it as its data component (delete any prior
   * data component so that its attributes won't overwrite the new component's)
   * Otherwise, place the new array into the out vector.
   */
  if (out[0])
  {
    if (DXGetObjectClass(out[0]) != CLASS_FIELD)
    {
      DXSetError(ERROR_INTERNAL, "non-field object found in output vector");
      goto error;
    }

    if (DXGetComponentValue((Field)out[0], "data"))
      DXDeleteComponent((Field)out[0], "data");

    if (! DXSetComponentValue((Field)out[0], "data", (Object)array))
      goto error;

  }
  else
    out[0] = (Object)array;

  /*
   * Now get the pointer to the contents of the array
   */
  out_data[0] = DXGetArrayData(array);
  if (! out_data[0])
    goto error;
  newdata = array;


  /* allocate new positions */

  newpositions = DXNewArray(TYPE_FLOAT,CATEGORY_REAL, 1, 3);
  if (!DXAddArrayData(newpositions, 0, out_knt[0], NULL))
    goto error;
  if (DXGetComponentValue((Field)out[0], "positions"))
    DXDeleteComponent((Field)out[0], "positions");

  DXSetComponentValue((Field)out[0],"positions",(Object) newpositions);

  newpositions_ptr = (Point *)DXGetArrayData(newpositions);


  /* ======================= TRANSFER AND MODIFY ================ */

  newdata_ptr=(float *) out_data[0];
 
  /* Now copy over the data that we want */

  if(in[2]) {
    iout=0;
    for (i=0; i<in_knt[0]; i++) { /* loop through all elements */
      /* check if it is selected by one of the probes */
      ipick=0;
      for(j=0;j<in_knt[2]; j++) { /* loop through all probes */
	vec[0] = *((float*) in_data[2]   +3*j);
	vec[1] = *((float*) in_data[2]+1 +3*j);
	vec[2] = *((float*) in_data[2]+2 +3*j);
	inpoint = oldpositions_ptr+i;
	if( (vec[0]-inpoint->x)*(vec[0]-inpoint->x) + (vec[1]-inpoint->y)*(vec[1]-inpoint->y) + (vec[2]-inpoint->z)*(vec[2]-inpoint->z) < radius) ipick=1;
      }
      if(ipick==0) {
	*newpositions_ptr=oldpositions_ptr[i];
	*newdata_ptr=olddata_ptr[i];
	newpositions_ptr++;
	newdata_ptr++;
	iout++;
      }
    }
  }
  else {
    for (i=0; i<in_knt[0]; i++) {
      newpositions_ptr[i]=oldpositions_ptr[i];
      newdata_ptr[i]=olddata_ptr[i];
    }
    iout=i;
  }
  sprintf(mstring," TRANSFERED %d of %d ELEMENTS",iout,i);
  DXMessage(mstring);
  


  /* finalize the field */
  DXEndField((Field)out[0]); 



  result =1;

  /*
   * In either event, clean up allocated memory
   */

error:
  return result;
}

int
RemovePoints_worker(
    int p_knt, int p_dim, float *p_positions,
    int field_knt, float *field_data,
    int radius_knt, float *radius_data,
    int probe_input_knt, float *probe_input_data,
    int output_1_knt, float *output_1_data)
{
  /*
   * The arguments to this routine are:
   *
   *  p_knt:           total count of input positions
   *  p_dim:           dimensionality of input positions
   *  p_positions:     pointer to positions list
   *
   * The following are inputs and therefore are read-only.  The default
   * values are given and should be used if the knt is 0.
   *
   * field_knt, field_data:  count and pointer for input "field"
   *                   no default value given.
   * radius_knt, radius_data:  count and pointer for input "radius"
   *                   non-descriptive default value is "0.2"
   * probe_input_knt, probe_input_data:  count and pointer for input "probe_input"
   *                   no default value given.
   *
   *  The output data buffer(s) are writable.
   *  The output buffer(s) are preallocated based on
   *     the dependency (positions or connections),
   *     the size of the corresponding positions or
   *     connections component in the first input, and
   *     the data type.
   *
   * output_1_knt, output_1_data:  count and pointer for output "output_1"
   */

  /*
   * User's code goes here
   */
     
     
  /*
   * successful completion
   */
   return 1;
     
  /*
   * unsuccessful completion
   */
error:
   return 0;
  
}
