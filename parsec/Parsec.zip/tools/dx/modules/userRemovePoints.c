/* Automatically generated - do not edit! */

#include <dx/dx.h>
#include <dx/modflags.h>

DXEntry()
{
    {
        extern Error m_RemovePoints(Object *, Object *);
        DXAddModule("RemovePoints", m_RemovePoints, 0,
            3, "field", "radius", "probe_input",
            1, "output_1");
    }
}
